```python
"""
Main entry point for the FastAPI application.

This file initializes the FastAPI app, includes routers, and sets up lifecycle events.
It implements the core application structure as per the system architecture, ensuring
scalability and modularity for a distributed video rendering system.
"""

from fastapi import FastAPI
from app.api.v1.endpoints import video
from app.core.config import settings
from app.core.logging import setup_logging
from app.db.session import engine
from app.models import video as video_model  # Import to create tables

# Setup structured logging
setup_logging()

# Create FastAPI app
app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="A high-performance backend for video rendering and processing."
)

# Include routers
app.include_router(video.router, prefix="/api/v1", tags=["video"])

# Lifecycle events
@app.on_event("startup")
async def startup_event():
    """
    Handles application startup: Creates database tables if needed.
    This aligns with the database node in the architecture (e.g., RDS setup).
    """
    # Create tables (in production, use Alembic for migrations)
    video_model.Base.metadata.create_all(bind=engine)

@app.on_event("shutdown")
async def shutdown_event():
    """
    Handles application shutdown: Close database connections.
    Ensures proper cleanup for scalability.
    """
    pass  # Engine disposal handled by SQLAlchemy

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```