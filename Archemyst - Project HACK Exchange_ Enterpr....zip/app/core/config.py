```python
"""
Configuration management using Pydantic BaseSettings.

Loads settings from environment variables for database, AWS services, etc.
This supports the configuration needs of services like S3, SQS, and databases in the architecture.
"""

from pydantic import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "Video Rendering Backend"
    VERSION: str = "1.0.0"
    DATABASE_URL: str  # e.g., postgresql://user:pass@localhost/db
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    AWS_REGION: str = "us-east-1"
    SQS_QUEUE_URL: Optional[str] = None
    S3_BUCKET_NAME: Optional[str] = None
    REDIS_URL: Optional[str] = None  # For caching if needed
    LOG_LEVEL: str = "INFO"

    class Config:
        env_file = ".env"

settings = Settings()
```