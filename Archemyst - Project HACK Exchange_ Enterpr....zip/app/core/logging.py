```python
"""
Structured logging setup using Python's logging module.

Configures JSON-formatted logs for better observability in a distributed system.
This supports robustness and monitoring for high-concurrency operations.
"""

import logging
import json
from pythonjsonlogger import jsonlogger

def setup_logging():
    """
    Sets up structured logging with JSON formatter.
    """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    # JSON formatter for structured logs
    formatter = jsonlogger.JsonFormatter(
        "%(asctime)s %(name)s %(levelname)s %(message)s"
    )
    
    # Console handler
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
```