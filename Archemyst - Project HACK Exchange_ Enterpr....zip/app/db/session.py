```python
"""
Database connection and session management using SQLAlchemy 2.0+.

Provides engine with connection pooling for high concurrency and scalability.
Aligns with database nodes (e.g., RDS) in the architecture.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from app.core.config import settings

# Create engine with pooling
engine = create_engine(
    settings.DATABASE_URL,
    pool_size=10,  # Adjust for concurrency
    max_overflow=20,
    pool_pre_ping=True  # Robustness for connection drops
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db() -> Session:
    """
    Dependency for FastAPI to get a DB session.
    Ensures sessions are properly closed.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```