```python
"""
SQLAlchemy models for video-related data.

Defines the database schema for video jobs, aligning with database nodes (e.g., RDS).
"""

from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Video(Base):
    __tablename__ = "videos"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    status = Column(String, default="pending")  # e.g., pending, rendering, completed
```