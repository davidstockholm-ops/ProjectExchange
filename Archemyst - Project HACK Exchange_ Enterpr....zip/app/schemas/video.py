```python
"""
Pydantic schemas for video data validation and serialization.

Used for API request/response models.
"""

from pydantic import BaseModel

class VideoBase(BaseModel):
    title: str

class VideoCreate(VideoBase):
    pass

class VideoResponse(VideoBase):
    id: int
    status: str

    class Config:
        orm_mode = True
```