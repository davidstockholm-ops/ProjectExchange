```python
"""
FastAPI router for video-related endpoints.

This implements API routes for video processing, aligning with the service nodes
(e.g., EC2 Renderer) in the architecture. It handles requests for rendering jobs.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.video import VideoCreate, VideoResponse
from app.services.video_service import VideoService

router = APIRouter()

@router.post("/videos/", response_model=VideoResponse)
async def create_video(video: VideoCreate, db: Session = Depends(get_db)):
    """
    Endpoint to create a new video rendering job.
    This triggers the video service, which communicates with queues (e.g., SQS) and storage (e.g., S3).
    """
    service = VideoService(db)
    try:
        result = await service.create_video_job(video)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating video job: {str(e)}")

@router.get("/videos/{video_id}", response_model=VideoResponse)
async def get_video(video_id: int, db: Session = Depends(get_db)):
    """
    Endpoint to retrieve a video job status.
    Queries the database (e.g., RDS) for job details.
    """
    service = VideoService(db)
    try:
        result = await service.get_video_job(video_id)
        if not result:
            raise HTTPException(status_code=404, detail="Video job not found")
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving video job: {str(e)}")
```